const toMinutes = (hhmm) => {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
};

const toHHMM = (mins) => `${String(Math.floor(mins / 60)).padStart(2, '0')}:${String(mins % 60).padStart(2, '0')}`;

// Returns every slot start time a doctor offers on the given YYYY-MM-DD date.
export function generateSlots(doctor, date) {
  const day = new Date(`${date}T00:00:00`).getDay();
  const slots = [];
  for (const window of doctor.availability.filter((w) => w.day === day)) {
    for (let t = toMinutes(window.start); t + doctor.slotDuration <= toMinutes(window.end); t += doctor.slotDuration) {
      slots.push(toHHMM(t));
    }
  }
  return [...new Set(slots)].sort();
}

export function isPast(date, slot) {
  return new Date(`${date}T${slot}:00`) <= new Date();
}
