import Doctor, { VERIFICATION_STATUSES } from '../models/Doctor.js';
import User from '../models/User.js';
import Appointment from '../models/Appointment.js';
import Hospital from '../models/Hospital.js';
import AppError, { asyncHandler } from '../utils/AppError.js';
import { abdmConfigured, lookupHprProfessional } from '../utils/abdm.js';
import { escapeRegex } from './doctorController.js';

const normalise = (s) => String(s || '').replace(/[\s-]/g, '').toLowerCase();

// GET /api/admin/stats
export const getStats = asyncHandler(async (_req, res) => {
  const [byStatus, patients, appointments, hospitals] = await Promise.all([
    Doctor.aggregate([{ $group: { _id: '$verification.status', count: { $sum: 1 } } }]),
    User.countDocuments({ role: 'patient' }),
    Appointment.countDocuments(),
    Hospital.countDocuments(),
  ]);
  const doctors = Object.fromEntries(VERIFICATION_STATUSES.map((s) => [s, 0]));
  for (const { _id, count } of byStatus) doctors[_id] = count;
  res.json({ doctors, patients, appointments, hospitals, abdmConfigured: abdmConfigured() });
});

// GET /api/admin/doctors?status=pending&search=
export const listDoctorsForReview = asyncHandler(async (req, res) => {
  const { status = 'pending', search } = req.query;
  const filter = {};
  if (VERIFICATION_STATUSES.includes(status)) filter['verification.status'] = status;
  if (search) {
    const rx = new RegExp(escapeRegex(String(search)), 'i');
    const users = await User.find({ role: 'doctor', $or: [{ name: rx }, { email: rx }] }).select('_id');
    filter.$or = [{ user: { $in: users.map((u) => u._id) } }, { registrationNumber: rx }, { city: rx }, { state: rx }];
  }
  const doctors = await Doctor.find(filter)
    .populate('user', 'name email phone createdAt')
    .populate('verification.verifiedBy', 'name')
    .sort({ createdAt: -1 })
    .limit(200);
  res.json({ count: doctors.length, doctors });
});

// PATCH /api/admin/doctors/:id/verification  { status: 'verified' | 'rejected' | 'pending', note }
export const setVerification = asyncHandler(async (req, res) => {
  const { status, note } = req.body;
  if (!VERIFICATION_STATUSES.includes(status)) throw new AppError(`Status must be one of: ${VERIFICATION_STATUSES.join(', ')}`, 400);
  if (status === 'rejected' && !String(note || '').trim()) throw new AppError('Please give a reason when rejecting', 400);

  const doctor = await Doctor.findById(req.params.id);
  if (!doctor) throw new AppError('Doctor not found', 404);

  const hprMatched = doctor.verification?.hprCheck?.found && doctor.verification.hprCheck.checkedAt;
  doctor.verification = {
    ...doctor.verification.toObject(),
    status,
    note: note?.trim() || undefined,
    method: status === 'verified' ? (hprMatched ? 'abdm-hpr' : 'manual') : undefined,
    verifiedAt: status === 'verified' ? new Date() : undefined,
    verifiedBy: status === 'verified' ? req.user._id : undefined,
  };
  await doctor.save({ validateBeforeSave: false });
  res.json({ doctor: await doctor.populate('user', 'name email phone createdAt') });
});

// POST /api/admin/doctors/:id/hpr-check  - looks the doctor's HPR ID up in ABDM and records the result
export const checkHpr = asyncHandler(async (req, res) => {
  const doctor = await Doctor.findById(req.params.id).populate('user', 'name email phone createdAt');
  if (!doctor) throw new AppError('Doctor not found', 404);
  if (!doctor.hprId) throw new AppError('This doctor has not provided an ABDM HPR ID', 400);
  if (!abdmConfigured()) {
    throw new AppError('ABDM HPR is not configured on the server. Add ABDM_CLIENT_ID, ABDM_CLIENT_SECRET and ABDM_HPR_LOOKUP_URL to server/.env', 503);
  }

  let result;
  try {
    result = await lookupHprProfessional(doctor.hprId);
  } catch (err) {
    throw new AppError(err.message, 502);
  }

  const registrationMatches =
    result.found && result.registrationNumber ? normalise(result.registrationNumber) === normalise(doctor.registrationNumber) : null;
  doctor.verification.hprCheck = { checkedAt: new Date(), ...result };
  await doctor.save({ validateBeforeSave: false });

  res.json({ doctor, hpr: { ...result, registrationMatches } });
});
