import Appointment, { ACTIVE_STATUSES } from '../models/Appointment.js';
import Doctor from '../models/Doctor.js';
import AppError, { asyncHandler } from '../utils/AppError.js';
import { generateSlots, isPast } from '../utils/slots.js';

const populate = (query) =>
  query
    .populate('patient', 'name email phone gender dateOfBirth bloodGroup')
    .populate({ path: 'doctor', select: 'specialization fees clinicAddress user', populate: { path: 'user', select: 'name email phone' } });

// POST /api/appointments  (patient)
export const bookAppointment = asyncHandler(async (req, res) => {
  const { doctorId, date, slot, reason } = req.body;
  if (!doctorId || !date || !slot) throw new AppError('doctorId, date and slot are required', 400);

  const doctor = await Doctor.findById(doctorId);
  if (!doctor || !doctor.isAvailable || doctor.verification?.status !== 'verified') {
    throw new AppError('Doctor is not available for booking', 404);
  }
  if (!generateSlots(doctor, date).includes(slot)) throw new AppError('Doctor does not offer this slot', 400);
  if (isPast(date, slot)) throw new AppError('Cannot book a slot in the past', 400);

  const clash = await Appointment.exists({ patient: req.user._id, date, slot, status: { $in: ACTIVE_STATUSES } });
  if (clash) throw new AppError('You already have an appointment at this time', 409);

  // The unique partial index on (doctor, date, slot) guards against double-booking races.
  const appointment = await Appointment.create({
    patient: req.user._id,
    doctor: doctor._id,
    date,
    slot,
    reason,
    fees: doctor.fees,
  });

  res.status(201).json({ appointment: await populate(Appointment.findById(appointment._id)) });
});

// GET /api/appointments/me?status=  (patient or doctor)
export const myAppointments = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.user.role === 'doctor') {
    const doctor = await Doctor.findOne({ user: req.user._id });
    if (!doctor) throw new AppError('Doctor profile not found', 404);
    filter.doctor = doctor._id;
  } else {
    filter.patient = req.user._id;
  }
  if (req.query.status) filter.status = req.query.status;

  const appointments = await populate(Appointment.find(filter).sort({ date: -1, slot: -1 }));
  res.json({ count: appointments.length, appointments });
});

// Allowed status transitions per role.
const TRANSITIONS = {
  doctor: { pending: ['confirmed', 'cancelled'], confirmed: ['completed', 'cancelled'] },
  patient: { pending: ['cancelled'], confirmed: ['cancelled'] },
};

// PATCH /api/appointments/:id/status  (patient or doctor)
export const updateStatus = asyncHandler(async (req, res) => {
  const { status, doctorNotes } = req.body;
  const appointment = await Appointment.findById(req.params.id);
  if (!appointment) throw new AppError('Appointment not found', 404);

  const { role } = req.user;
  if (role === 'doctor') {
    const doctor = await Doctor.findOne({ user: req.user._id });
    if (!doctor || !appointment.doctor.equals(doctor._id)) throw new AppError('Not your appointment', 403);
  } else if (!appointment.patient.equals(req.user._id)) {
    throw new AppError('Not your appointment', 403);
  }

  if (status && status !== appointment.status) {
    const allowed = TRANSITIONS[role]?.[appointment.status] || [];
    if (!allowed.includes(status)) {
      throw new AppError(`Cannot change status from '${appointment.status}' to '${status}'`, 400);
    }
    appointment.status = status;
  }
  if (role === 'doctor' && doctorNotes !== undefined) appointment.doctorNotes = doctorNotes;

  await appointment.save();
  res.json({ appointment: await populate(Appointment.findById(appointment._id)) });
});
