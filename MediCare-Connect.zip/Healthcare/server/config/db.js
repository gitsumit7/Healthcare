import mongoose from 'mongoose';

let memoryServer;

// Connects to MONGO_URI, or spins up an in-memory MongoDB when none is configured.
export async function connectDB() {
  let uri = process.env.MONGO_URI;
  let inMemory = false;

  if (!uri) {
    const { MongoMemoryServer } = await import('mongodb-memory-server');
    memoryServer = await MongoMemoryServer.create();
    uri = memoryServer.getUri('medicare_connect');
    inMemory = true;
  }

  const conn = await mongoose.connect(uri);
  console.log(`MongoDB connected: ${conn.connection.host}${inMemory ? ' (in-memory)' : ''}`);
  return { inMemory };
}

export async function disconnectDB() {
  await mongoose.disconnect();
  if (memoryServer) await memoryServer.stop();
}
