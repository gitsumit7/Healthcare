import { useEffect, useRef, useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { errorMessage } from '../api/client.js';

const CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
const SCRIPT_SRC = 'https://accounts.google.com/gsi/client';

let scriptPromise;
const loadGoogleScript = () => {
  scriptPromise ??= new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = SCRIPT_SRC;
    script.async = true;
    script.onload = () => resolve(window.google);
    script.onerror = () => {
      scriptPromise = undefined;
      reject(new Error('Could not load Google sign-in. Check your internet connection.'));
    };
    document.head.appendChild(script);
  });
  return scriptPromise;
};

const GoogleLogo = () => (
  <svg viewBox="0 0 48 48" width="18" height="18" aria-hidden="true">
    <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z" />
    <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
    <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z" />
    <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z" />
  </svg>
);

/**
 * "Continue with Google" via Google Identity Services. Google returns a signed ID token,
 * which the backend verifies before logging the user in (or creating a patient account).
 */
export default function GoogleSignInButton({ onSuccess, text = 'continue_with' }) {
  const { googleLogin } = useAuth();
  const containerRef = useRef(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [showSetupHint, setShowSetupHint] = useState(false);

  useEffect(() => {
    if (!CLIENT_ID) return undefined;
    let cancelled = false;

    const handleCredential = async ({ credential }) => {
      setBusy(true);
      setError('');
      try {
        const result = await googleLogin(credential);
        onSuccess?.(result);
      } catch (err) {
        setError(errorMessage(err));
      } finally {
        setBusy(false);
      }
    };

    const render = (google) => {
      const el = containerRef.current;
      if (cancelled || !el) return;
      google.accounts.id.initialize({ client_id: CLIENT_ID, callback: handleCredential, ux_mode: 'popup' });
      el.innerHTML = '';
      // Google's button needs a pixel width (200-400); match the form width.
      const width = Math.max(200, Math.min(400, Math.floor(el.parentElement.offsetWidth)));
      google.accounts.id.renderButton(el, { theme: 'outline', size: 'large', shape: 'rectangular', text, width });
    };

    loadGoogleScript()
      .then(render)
      .catch((err) => !cancelled && setError(err.message));

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!CLIENT_ID) {
    // Without a client ID the button is hidden in production; in development it explains the setup.
    if (!import.meta.env.DEV) return null;
    return (
      <div className="google-signin">
        <button type="button" className="btn btn-outline btn-block google-fallback" onClick={() => setShowSetupHint(true)}>
          <GoogleLogo /> Continue with Google
        </button>
        {showSetupHint && (
          <div className="demo-box small">
            <strong>Google sign-in isn&apos;t set up yet.</strong> Create an OAuth Client ID in Google Cloud Console,
            then set <code>VITE_GOOGLE_CLIENT_ID</code> in <code>client/.env</code> and <code>GOOGLE_CLIENT_ID</code> in{' '}
            <code>server/.env</code>, and restart <code>npm run dev</code>. See the README for steps.
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="google-signin">
      <div ref={containerRef} className={`google-btn ${busy ? 'busy' : ''}`} />
      {busy && <p className="muted small center">Signing you in…</p>}
      {error && <div className="alert alert-error">{error}</div>}
    </div>
  );
}
