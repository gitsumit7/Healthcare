import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);

  return (
    <header className="navbar">
      <div className="container navbar-inner">
        <Link to="/" className="brand" onClick={close}>
          <span className="brand-mark">+</span> MediCare <strong>Connect</strong>
        </Link>
        <button className="nav-toggle" aria-label="Toggle menu" onClick={() => setOpen((o) => !o)}>
          ☰
        </button>
        <nav className={`nav-links ${open ? 'open' : ''}`}>
          <NavLink to="/doctors" onClick={close}>Find Doctors</NavLink>
          <NavLink to="/hospitals" onClick={close}>Hospitals</NavLink>
          {user ? (
            <>
              {user.role === 'admin' ? (
                <NavLink to="/admin" onClick={close}>Admin</NavLink>
              ) : (
                <NavLink to="/dashboard" onClick={close}>Dashboard</NavLink>
              )}
              <NavLink to="/profile" onClick={close}>Profile</NavLink>
              <span className="nav-user">Hi, {user.name.split(' ')[0]}</span>
              <button
                className="btn btn-outline btn-sm"
                onClick={() => {
                  logout();
                  close();
                  navigate('/');
                }}
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <NavLink to="/login" onClick={close}>Login</NavLink>
              <Link to="/register" className="btn btn-primary btn-sm" onClick={close}>Sign up</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
