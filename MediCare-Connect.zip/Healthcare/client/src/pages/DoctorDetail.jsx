import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { appointmentApi, doctorApi, errorMessage } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';
import Spinner from '../components/Spinner.jsx';
import Alert from '../components/Alert.jsx';
import { VerifiedBadge, DemoBadge } from '../components/DoctorCard.jsx';
import { DAYS, formatDate, formatTime, initials, nextDays, toDateKey } from '../utils.js';

const BOOKING_WINDOW_DAYS = 14;

export default function DoctorDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [doctor, setDoctor] = useState(null);
  const [date, setDate] = useState(toDateKey(new Date()));
  const [slots, setSlots] = useState([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [slot, setSlot] = useState('');
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');
  const [booking, setBooking] = useState(false);
  const [booked, setBooked] = useState(null);

  useEffect(() => {
    doctorApi.get(id).then(setDoctor).catch((err) => setError(errorMessage(err)));
  }, [id]);

  useEffect(() => {
    setSlot('');
    setSlotsLoading(true);
    doctorApi
      .slots(id, date)
      .then((d) => setSlots(d.slots))
      .catch((err) => setError(errorMessage(err)))
      .finally(() => setSlotsLoading(false));
  }, [id, date, booked]);

  const book = async () => {
    if (!user) return navigate('/login', { state: { from: `/doctors/${id}` } });
    setBooking(true);
    setError('');
    try {
      setBooked(await appointmentApi.book({ doctorId: id, date, slot, reason }));
      setReason('');
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBooking(false);
    }
  };

  if (!doctor) return error ? <Alert>{error}</Alert> : <Spinner />;

  const workingDays = [...new Set(doctor.availability.map((w) => w.day))].sort();

  return (
    <div className="detail-layout">
      <section className="card">
        <div className="doctor-card-head">
          <div className="avatar avatar-lg">{initials(doctor.user.name)}</div>
          <div>
            <h1>{doctor.user.name}</h1>
            <p className="accent">{doctor.specialization}</p>
            <p className="muted small">{doctor.qualifications}</p>
            <div className="badges">
              {doctor.verification?.status === 'verified' && <VerifiedBadge />}
              {doctor.isDemo && <DemoBadge />}
            </div>
          </div>
        </div>
        {doctor.isDemo && (
          <p className="demo-note small">This is a sample profile for demonstration — not a real doctor.</p>
        )}
        <ul className="doctor-meta">
          <li><strong>{doctor.experience}</strong> yrs experience</li>
          <li><strong>₹{doctor.fees}</strong> consultation</li>
          <li><strong>{doctor.slotDuration}</strong> min slots</li>
        </ul>
        {doctor.about && (
          <>
            <h3>About</h3>
            <p>{doctor.about}</p>
          </>
        )}
        {doctor.hospital?._id && (
          <p className="doctor-hospital">
            🏥 Practises at <Link to={`/hospitals/${doctor.hospital._id}`}>{doctor.hospital.name}</Link>
            {doctor.hospital.isDemo && <span className="muted small"> (demo hospital)</span>}
          </p>
        )}
        <p>
          📍 {[doctor.hospital?._id ? null : doctor.clinicAddress, doctor.city, doctor.state].filter(Boolean).join(', ')}
          {doctor.pincode && ` – ${doctor.pincode}`}
        </p>
        <h3>Registration</h3>
        <ul className="hours">
          <li><span>Registration no.</span><span>{doctor.registrationNumber}</span></li>
          <li><span>Council</span><span>{doctor.medicalCouncil}</span></li>
          {doctor.registrationYear && <li><span>Year</span><span>{doctor.registrationYear}</span></li>}
          {doctor.hprId && <li><span>ABDM HPR ID</span><span>{doctor.hprId}</span></li>}
        </ul>
        <h3>Working hours</h3>
        <ul className="hours">
          {workingDays.map((day) => (
            <li key={day}>
              <span>{DAYS[day]}</span>
              <span>
                {doctor.availability
                  .filter((w) => w.day === day)
                  .map((w) => `${formatTime(w.start)} – ${formatTime(w.end)}`)
                  .join(', ')}
              </span>
            </li>
          ))}
        </ul>
      </section>

      <section className="card booking">
        <h2>Book an appointment</h2>
        {booked && (
          <Alert type="success">
            Booked for {formatDate(booked.date)} at {formatTime(booked.slot)}. Status: pending confirmation.{' '}
            <Link to="/dashboard">View in dashboard →</Link>
          </Alert>
        )}
        <Alert>{error}</Alert>

        <h4>Select date</h4>
        <div className="date-strip">
          {nextDays(BOOKING_WINDOW_DAYS).map((d) => {
            const key = toDateKey(d);
            const works = workingDays.includes(d.getDay());
            return (
              <button
                key={key}
                type="button"
                disabled={!works}
                className={`date-pill ${key === date ? 'active' : ''}`}
                onClick={() => setDate(key)}
              >
                <span>{d.toLocaleDateString(undefined, { weekday: 'short' })}</span>
                <strong>{d.getDate()}</strong>
                <span>{d.toLocaleDateString(undefined, { month: 'short' })}</span>
              </button>
            );
          })}
        </div>

        <h4>Select time</h4>
        {slotsLoading ? (
          <Spinner label="Checking availability…" />
        ) : slots.length === 0 ? (
          <p className="empty">The doctor is not available on this day.</p>
        ) : (
          <div className="slot-grid">
            {slots.map((s) => (
              <button
                key={s.time}
                type="button"
                disabled={!s.available}
                className={`slot ${slot === s.time ? 'active' : ''}`}
                onClick={() => setSlot(s.time)}
              >
                {formatTime(s.time)}
              </button>
            ))}
          </div>
        )}

        <label className="field">
          Reason for visit (optional)
          <textarea rows={3} maxLength={500} value={reason} onChange={(e) => setReason(e.target.value)} />
        </label>

        {user && user.role !== 'patient' ? (
          <p className="muted">Only patient accounts can book appointments.</p>
        ) : (
          <button className="btn btn-primary btn-block" disabled={!slot || booking} onClick={book}>
            {booking ? 'Booking…' : user ? `Confirm booking${slot ? ` · ${formatTime(slot)}` : ''}` : 'Login to book'}
          </button>
        )}
      </section>
    </div>
  );
}
