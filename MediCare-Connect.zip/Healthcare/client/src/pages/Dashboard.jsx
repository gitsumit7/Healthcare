import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, Navigate, useLocation } from 'react-router-dom';
import VerificationBanner from '../components/VerificationBanner.jsx';
import { appointmentApi, errorMessage } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';
import Spinner from '../components/Spinner.jsx';
import Alert from '../components/Alert.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import { formatDate, formatTime, isUpcoming } from '../utils.js';

const TABS = {
  upcoming: (a) => ['pending', 'confirmed'].includes(a.status) && isUpcoming(a),
  past: (a) => !(['pending', 'confirmed'].includes(a.status) && isUpcoming(a)),
  all: () => true,
};

export default function Dashboard() {
  const { user } = useAuth();
  // Admins have no appointments of their own; their home is the verification console.
  if (user.role === 'admin') return <Navigate to="/admin" replace />;
  return <AppointmentsDashboard />;
}

function AppointmentsDashboard() {
  const { user, doctor } = useAuth();
  const location = useLocation();
  const isDoctor = user.role === 'doctor';
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tab, setTab] = useState('upcoming');
  const [busyId, setBusyId] = useState(null);

  const load = useCallback(() => {
    setLoading(true);
    appointmentApi
      .mine()
      .then(setAppointments)
      .catch((err) => setError(errorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  useEffect(load, [load]);

  const stats = useMemo(
    () => ({
      total: appointments.length,
      upcoming: appointments.filter(TABS.upcoming).length,
      pending: appointments.filter((a) => a.status === 'pending').length,
      completed: appointments.filter((a) => a.status === 'completed').length,
    }),
    [appointments]
  );

  const visible = appointments
    .filter(TABS[tab])
    .sort((a, b) => {
      const cmp = `${a.date}${a.slot}`.localeCompare(`${b.date}${b.slot}`);
      return tab === 'upcoming' ? cmp : -cmp;
    });

  const update = async (appt, data, confirmText) => {
    if (confirmText && !window.confirm(confirmText)) return;
    setBusyId(appt._id);
    setError('');
    try {
      const updated = await appointmentApi.updateStatus(appt._id, data);
      setAppointments((list) => list.map((a) => (a._id === updated._id ? updated : a)));
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusyId(null);
    }
  };

  const addNotes = (appt) => {
    const notes = window.prompt('Consultation notes / prescription', appt.doctorNotes || '');
    if (notes !== null) update(appt, { doctorNotes: notes });
  };

  return (
    <section>
      <div className="section-head">
        <div>
          <h1>{isDoctor ? 'Doctor dashboard' : 'My appointments'}</h1>
          <p className="muted">Welcome, {user.name}</p>
        </div>
        {!isDoctor && (
          <Link to="/doctors" className="btn btn-primary">+ Book appointment</Link>
        )}
      </div>

      {isDoctor && doctor && <VerificationBanner verification={doctor.verification} showProfileLink />}
      {location.state?.passwordReset &&<Alert type="success">Your password has been reset and you are logged in.</Alert>}

      <div className="stats">
        <div className="stat card"><span>Total</span><strong>{stats.total}</strong></div>
        <div className="stat card"><span>Upcoming</span><strong>{stats.upcoming}</strong></div>
        <div className="stat card"><span>Pending</span><strong>{stats.pending}</strong></div>
        <div className="stat card"><span>Completed</span><strong>{stats.completed}</strong></div>
      </div>

      <div className="tabs">
        {Object.keys(TABS).map((t) => (
          <button key={t} className={tab === t ? 'active' : ''} onClick={() => setTab(t)}>
            {t[0].toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      <Alert>{error}</Alert>
      {loading ? (
        <Spinner />
      ) : visible.length === 0 ? (
        <p className="empty">No {tab === 'all' ? '' : tab} appointments.</p>
      ) : (
        <div className="appt-list">
          {visible.map((a) => {
            const busy = busyId === a._id;
            const upcoming = isUpcoming(a);
            return (
              <article key={a._id} className="card appt">
                <div className="appt-when">
                  <strong>{formatTime(a.slot)}</strong>
                  <span>{formatDate(a.date)}</span>
                </div>
                <div className="appt-body">
                  {isDoctor ? (
                    <>
                      <h3>{a.patient?.name}</h3>
                      <p className="muted small">
                        {a.patient?.email} {a.patient?.phone && `· ${a.patient.phone}`}
                        {a.patient?.bloodGroup && ` · Blood group ${a.patient.bloodGroup}`}
                      </p>
                    </>
                  ) : (
                    <>
                      <h3>{a.doctor?.user?.name}</h3>
                      <p className="muted small">
                        {a.doctor?.specialization} · ₹{a.fees} {a.doctor?.clinicAddress && `· ${a.doctor.clinicAddress}`}
                      </p>
                    </>
                  )}
                  {a.reason && <p className="small"><strong>Reason:</strong> {a.reason}</p>}
                  {a.doctorNotes && <p className="small notes"><strong>Doctor&apos;s notes:</strong> {a.doctorNotes}</p>}
                </div>
                <div className="appt-actions">
                  <StatusBadge status={a.status} />
                  {isDoctor && a.status === 'pending' && (
                    <button className="btn btn-primary btn-sm" disabled={busy} onClick={() => update(a, { status: 'confirmed' })}>
                      Confirm
                    </button>
                  )}
                  {isDoctor && a.status === 'confirmed' && (
                    <button className="btn btn-primary btn-sm" disabled={busy} onClick={() => update(a, { status: 'completed' })}>
                      Mark completed
                    </button>
                  )}
                  {isDoctor && a.status !== 'cancelled' && (
                    <button className="btn btn-outline btn-sm" disabled={busy} onClick={() => addNotes(a)}>
                      {a.doctorNotes ? 'Edit notes' : 'Add notes'}
                    </button>
                  )}
                  {['pending', 'confirmed'].includes(a.status) && (isDoctor || upcoming) && (
                    <button
                      className="btn btn-danger btn-sm"
                      disabled={busy}
                      onClick={() => update(a, { status: 'cancelled' }, 'Cancel this appointment?')}
                    >
                      Cancel
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}
